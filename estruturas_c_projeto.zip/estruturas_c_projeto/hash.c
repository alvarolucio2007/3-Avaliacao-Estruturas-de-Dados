#include "hash.h"
#include <stdlib.h>
static size_t indice(int x,size_t n){return ((unsigned)x)%n;}
int hash_init(Hash*h,size_t n){if(!n)return 0;h->baldes=calloc(n,sizeof(HashNo*));if(!h->baldes)return 0;h->capacidade=n;return 1;}
int hash_insert(Hash*h,int x){if(!h->capacidade)return 0;size_t i=indice(x,h->capacidade);for(HashNo*p=h->baldes[i];p;p=p->prox)if(p->chave==x)return 1;HashNo*n=malloc(sizeof(*n));if(!n)return 0;n->chave=x;n->prox=h->baldes[i];h->baldes[i]=n;return 1;}
int hash_contains(const Hash*h,int x){if(!h->capacidade)return 0;for(HashNo*p=h->baldes[indice(x,h->capacidade)];p;p=p->prox)if(p->chave==x)return 1;return 0;}
int hash_remove(Hash*h,int x){if(!h->capacidade)return 0;size_t i=indice(x,h->capacidade);HashNo*p=h->baldes[i],*a=NULL;while(p&&p->chave!=x){a=p;p=p->prox;}if(!p)return 0;if(a)a->prox=p->prox;else h->baldes[i]=p->prox;free(p);return 1;}
void hash_free(Hash*h){if(!h->baldes)return;for(size_t i=0;i<h->capacidade;i++){HashNo*p=h->baldes[i];while(p){HashNo*n=p->prox;free(p);p=n;}}free(h->baldes);h->baldes=NULL;h->capacidade=0;}
