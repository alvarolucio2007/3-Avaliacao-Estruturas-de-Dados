#include "abb.h"
#include <stdio.h>
#include <stdlib.h>
static ABBNo*novo(int x){ABBNo*n=malloc(sizeof(*n));if(n){n->valor=x;n->esq=n->dir=NULL;}return n;}
void abb_init(ABB*a){a->raiz=NULL;}
static int ins(ABBNo**p,int x){if(!*p){*p=novo(x);return *p!=NULL;}if(x==(*p)->valor)return 1;return x<(*p)->valor?ins(&(*p)->esq,x):ins(&(*p)->dir,x);}
int abb_insert(ABB*a,int x){return ins(&a->raiz,x);}
int abb_contains(const ABB*a,int x){ABBNo*p=a->raiz;while(p){if(x==p->valor)return 1;p=x<p->valor?p->esq:p->dir;}return 0;}
static void ino(ABBNo*p){if(!p)return;ino(p->esq);printf("%d ",p->valor);ino(p->dir);}
void abb_inorder(const ABB*a){ino(a->raiz);}
static void fr(ABBNo*p){if(!p)return;fr(p->esq);fr(p->dir);free(p);}
void abb_free(ABB*a){fr(a->raiz);a->raiz=NULL;}
