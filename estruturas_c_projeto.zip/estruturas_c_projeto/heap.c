#include "heap.h"
#include <stdlib.h>
static void troca(int*a,int*b){int t=*a;*a=*b;*b=t;}
void heap_init(Heap*h){h->dados=NULL;h->tamanho=h->capacidade=0;}
int heap_push(Heap*h,int x){if(h->tamanho==h->capacidade){size_t c=h->capacidade?h->capacidade*2:8;int*p=realloc(h->dados,c*sizeof(int));if(!p)return 0;h->dados=p;h->capacidade=c;}size_t i=h->tamanho++;h->dados[i]=x;while(i>0){size_t pai=(i-1)/2;if(h->dados[pai]<=h->dados[i])break;troca(&h->dados[pai],&h->dados[i]);i=pai;}return 1;}
int heap_peek(const Heap*h,int*out){if(!h->tamanho||!out)return 0;*out=h->dados[0];return 1;}
int heap_pop(Heap*h,int*out){if(!h->tamanho||!out)return 0;*out=h->dados[0];h->dados[0]=h->dados[--h->tamanho];size_t i=0;for(;;){size_t e=2*i+1,d=e+1,m=i;if(e<h->tamanho&&h->dados[e]<h->dados[m])m=e;if(d<h->tamanho&&h->dados[d]<h->dados[m])m=d;if(m==i)break;troca(&h->dados[i],&h->dados[m]);i=m;}return 1;}
void heap_free(Heap*h){free(h->dados);heap_init(h);}
