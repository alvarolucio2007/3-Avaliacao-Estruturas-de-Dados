#ifndef DEQUE_H
#define DEQUE_H
typedef struct DequeNo {int valor;struct DequeNo*ant,*prox;} DequeNo;
typedef struct {DequeNo*inicio,*fim;} Deque;
void deque_init(Deque*d);
int deque_push_front(Deque*d,int x);
int deque_push_back(Deque*d,int x);
int deque_pop_front(Deque*d,int*out);
int deque_pop_back(Deque*d,int*out);
void deque_free(Deque*d);
#endif
