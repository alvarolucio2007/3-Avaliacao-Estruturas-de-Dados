#include "fila.h"
#include <stdlib.h>
void fila_init(Fila*f){f->inicio=f->fim=NULL;}
int fila_enqueue(Fila*f,int x){FilaNo*n=malloc(sizeof(*n));if(!n)return 0;n->valor=x;n->prox=NULL;if(f->fim)f->fim->prox=n;else f->inicio=n;f->fim=n;return 1;}
int fila_dequeue(Fila*f,int*out){if(!f->inicio||!out)return 0;FilaNo*n=f->inicio;*out=n->valor;f->inicio=n->prox;if(!f->inicio)f->fim=NULL;free(n);return 1;}
int fila_empty(const Fila*f){return f->inicio==NULL;}
void fila_free(Fila*f){int x;while(fila_dequeue(f,&x)){}}
