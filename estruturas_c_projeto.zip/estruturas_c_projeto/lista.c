#include "lista.h"
#include <stdio.h>
#include <stdlib.h>
void lista_init(Lista*l){l->inicio=NULL;}
int lista_push_front(Lista*l,int x){ListaNo*n=malloc(sizeof(*n));if(!n)return 0;n->valor=x;n->prox=l->inicio;l->inicio=n;return 1;}
int lista_push_back(Lista*l,int x){ListaNo*n=malloc(sizeof(*n));if(!n)return 0;n->valor=x;n->prox=NULL;if(!l->inicio){l->inicio=n;return 1;}ListaNo*p=l->inicio;while(p->prox)p=p->prox;p->prox=n;return 1;}
int lista_remove(Lista*l,int x){ListaNo*p=l->inicio,*ant=NULL;while(p&&p->valor!=x){ant=p;p=p->prox;}if(!p)return 0;if(ant)ant->prox=p->prox;else l->inicio=p->prox;free(p);return 1;}
int lista_contains(const Lista*l,int x){for(ListaNo*p=l->inicio;p;p=p->prox)if(p->valor==x)return 1;return 0;}
void lista_print(const Lista*l){for(ListaNo*p=l->inicio;p;p=p->prox)printf("%d ",p->valor);puts("");}
void lista_free(Lista*l){ListaNo*p=l->inicio;while(p){ListaNo*n=p->prox;free(p);p=n;}l->inicio=NULL;}
