#ifndef FILA_H
#define FILA_H
typedef struct FilaNo {int valor;struct FilaNo*prox;} FilaNo;
typedef struct {FilaNo*inicio,*fim;} Fila;
void fila_init(Fila*f);
int fila_enqueue(Fila*f,int x);
int fila_dequeue(Fila*f,int*out);
int fila_empty(const Fila*f);
void fila_free(Fila*f);
#endif
