#ifndef VETOR_H
#define VETOR_H
#include <stddef.h>
typedef struct { int *dados; size_t tamanho, capacidade; } Vetor;
void vetor_init(Vetor *v);
int vetor_push(Vetor *v, int valor);
int vetor_get(const Vetor *v, size_t indice, int *saida);
int vetor_set(Vetor *v, size_t indice, int valor);
void vetor_print(const Vetor *v);
void vetor_free(Vetor *v);
#endif
