#ifndef HEAP_H
#define HEAP_H
#include <stddef.h>
typedef struct {int*dados;size_t tamanho,capacidade;} Heap;
void heap_init(Heap*h);
int heap_push(Heap*h,int x);
int heap_pop(Heap*h,int*out);
int heap_peek(const Heap*h,int*out);
void heap_free(Heap*h);
#endif
