#include <stdio.h>
#include "vetor.h"
#include "lista.h"
#include "lista_dupla.h"
#include "lista_circular.h"
#include "pilha.h"
#include "fila.h"
#include "deque.h"
#include "hash.h"
#include "abb.h"
#include "heap.h"
#include "grafo.h"

int main(void) {
    printf("=== Demonstração das estruturas ===\n");

    Vetor v; vetor_init(&v);
    vetor_push(&v, 10); vetor_push(&v, 20);
    printf("Vetor: "); vetor_print(&v); vetor_free(&v);

    Lista l; lista_init(&l);
    lista_push_front(&l, 7); lista_push_back(&l, 9);
    printf("Lista: "); lista_print(&l); lista_free(&l);

    ListaDupla ld; lista_dupla_init(&ld);
    lista_dupla_push_back(&ld, 3); lista_dupla_push_back(&ld, 4);
    printf("Lista dupla: "); lista_dupla_print(&ld); lista_dupla_free(&ld);

    ListaCircular lc; lista_circular_init(&lc);
    lista_circular_push_back(&lc, 1); lista_circular_push_back(&lc, 2);
    printf("Lista circular: "); lista_circular_print(&lc); lista_circular_free(&lc);

    Pilha p; pilha_init(&p);
    pilha_push(&p, 100); pilha_push(&p, 200);
    int x; if (pilha_pop(&p, &x)) printf("Pilha pop: %d\n", x);
    pilha_free(&p);

    Fila f; fila_init(&f);
    fila_enqueue(&f, 11); fila_enqueue(&f, 22);
    if (fila_dequeue(&f, &x)) printf("Fila dequeue: %d\n", x);
    fila_free(&f);

    Deque d; deque_init(&d);
    deque_push_front(&d, 8); deque_push_back(&d, 9);
    if (deque_pop_front(&d, &x)) printf("Deque pop frente: %d\n", x);
    deque_free(&d);

    Hash h; hash_init(&h, 17);
    hash_insert(&h, 42); hash_insert(&h, 59);
    printf("Hash contém 42? %s\n", hash_contains(&h, 42) ? "sim" : "não");
    hash_free(&h);

    ABB a; abb_init(&a);
    abb_insert(&a, 8); abb_insert(&a, 3); abb_insert(&a, 12);
    printf("ABB em ordem: "); abb_inorder(&a); puts("");
    abb_free(&a);

    Heap heap; heap_init(&heap);
    heap_push(&heap, 30); heap_push(&heap, 10); heap_push(&heap, 20);
    if (heap_pop(&heap, &x)) printf("Heap mínimo: %d\n", x);
    heap_free(&heap);

    Grafo g; grafo_init(&g, 4);
    grafo_add_edge(&g, 0, 1); grafo_add_edge(&g, 1, 2); grafo_add_edge(&g, 2, 3);
    printf("Grafo: vizinhos do vértice 1: "); grafo_print_neighbors(&g, 1);
    grafo_free(&g);

    return 0;
}
