#ifndef HASH_H
#define HASH_H
#include <stddef.h>
typedef struct HashNo {int chave;struct HashNo*prox;} HashNo;
typedef struct {HashNo**baldes;size_t capacidade;} Hash;
int hash_init(Hash*h,size_t capacidade);
int hash_insert(Hash*h,int chave);
int hash_contains(const Hash*h,int chave);
int hash_remove(Hash*h,int chave);
void hash_free(Hash*h);
#endif
