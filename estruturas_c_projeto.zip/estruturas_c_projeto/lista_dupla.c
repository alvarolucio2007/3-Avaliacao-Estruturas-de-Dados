#include "lista_dupla.h"
#include <stdio.h>
#include <stdlib.h>
void lista_dupla_init(ListaDupla*l){l->inicio=l->fim=NULL;}
int lista_dupla_push_back(ListaDupla*l,int x){ListaDuplaNo*n=malloc(sizeof(*n));if(!n)return 0;n->valor=x;n->prox=NULL;n->ant=l->fim;if(l->fim)l->fim->prox=n;else l->inicio=n;l->fim=n;return 1;}
int lista_dupla_remove(ListaDupla*l,int x){ListaDuplaNo*p=l->inicio;while(p&&p->valor!=x)p=p->prox;if(!p)return 0;if(p->ant)p->ant->prox=p->prox;else l->inicio=p->prox;if(p->prox)p->prox->ant=p->ant;else l->fim=p->ant;free(p);return 1;}
void lista_dupla_print(const ListaDupla*l){for(ListaDuplaNo*p=l->inicio;p;p=p->prox)printf("%d ",p->valor);puts("");}
void lista_dupla_free(ListaDupla*l){ListaDuplaNo*p=l->inicio;while(p){ListaDuplaNo*n=p->prox;free(p);p=n;}l->inicio=l->fim=NULL;}
