#ifndef ABB_H
#define ABB_H
typedef struct ABBNo {int valor;struct ABBNo*esq,*dir;} ABBNo;
typedef struct {ABBNo*raiz;} ABB;
void abb_init(ABB*a);
int abb_insert(ABB*a,int x);
int abb_contains(const ABB*a,int x);
void abb_inorder(const ABB*a);
void abb_free(ABB*a);
#endif
