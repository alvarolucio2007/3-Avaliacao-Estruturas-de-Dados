#ifndef GRAFO_H
#define GRAFO_H
#include <stddef.h>
typedef struct Aresta {size_t destino;struct Aresta*prox;} Aresta;
typedef struct {size_t vertices;Aresta**listas;} Grafo;
int grafo_init(Grafo*g,size_t vertices);
int grafo_add_edge(Grafo*g,size_t a,size_t b);
void grafo_print_neighbors(const Grafo*g,size_t v);
void grafo_free(Grafo*g);
#endif
