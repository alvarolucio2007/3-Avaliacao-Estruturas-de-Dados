#include "lista_circular.h"
#include <stdio.h>
#include <stdlib.h>
void lista_circular_init(ListaCircular*l){l->ultimo=NULL;}
int lista_circular_push_back(ListaCircular*l,int x){LCNo*n=malloc(sizeof(*n));if(!n)return 0;if(!l->ultimo){n->prox=n;l->ultimo=n;}else{n->prox=l->ultimo->prox;l->ultimo->prox=n;l->ultimo=n;}return 1;}
void lista_circular_print(const ListaCircular*l){if(!l->ultimo){puts("");return;}LCNo*p=l->ultimo->prox;do{printf("%d ",p->valor);p=p->prox;}while(p!=l->ultimo->prox);puts("");}
void lista_circular_free(ListaCircular*l){if(!l->ultimo)return;LCNo*inicio=l->ultimo->prox;l->ultimo->prox=NULL;while(inicio){LCNo*n=inicio->prox;free(inicio);inicio=n;}l->ultimo=NULL;}
