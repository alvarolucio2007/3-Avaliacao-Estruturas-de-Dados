#include "deque.h"
#include <stdlib.h>
void deque_init(Deque*d){d->inicio=d->fim=NULL;}
static int add(Deque*d,int x,int front){DequeNo*n=malloc(sizeof(*n));if(!n)return 0;n->valor=x;n->ant=n->prox=NULL;if(front){n->prox=d->inicio;if(d->inicio)d->inicio->ant=n;else d->fim=n;d->inicio=n;}else{n->ant=d->fim;if(d->fim)d->fim->prox=n;else d->inicio=n;d->fim=n;}return 1;}
int deque_push_front(Deque*d,int x){return add(d,x,1);}
int deque_push_back(Deque*d,int x){return add(d,x,0);}
int deque_pop_front(Deque*d,int*out){if(!d->inicio||!out)return 0;DequeNo*n=d->inicio;*out=n->valor;d->inicio=n->prox;if(d->inicio)d->inicio->ant=NULL;else d->fim=NULL;free(n);return 1;}
int deque_pop_back(Deque*d,int*out){if(!d->fim||!out)return 0;DequeNo*n=d->fim;*out=n->valor;d->fim=n->ant;if(d->fim)d->fim->prox=NULL;else d->inicio=NULL;free(n);return 1;}
void deque_free(Deque*d){int x;while(deque_pop_front(d,&x)){}}
