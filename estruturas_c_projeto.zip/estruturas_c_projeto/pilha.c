#include "pilha.h"
#include <stdlib.h>
void pilha_init(Pilha*p){p->topo=NULL;}
int pilha_push(Pilha*p,int x){PilhaNo*n=malloc(sizeof(*n));if(!n)return 0;n->valor=x;n->prox=p->topo;p->topo=n;return 1;}
int pilha_pop(Pilha*p,int*out){if(!p->topo||!out)return 0;PilhaNo*n=p->topo;*out=n->valor;p->topo=n->prox;free(n);return 1;}
int pilha_peek(const Pilha*p,int*out){if(!p->topo||!out)return 0;*out=p->topo->valor;return 1;}
int pilha_empty(const Pilha*p){return p->topo==NULL;}
void pilha_free(Pilha*p){int x;while(pilha_pop(p,&x)){}}
