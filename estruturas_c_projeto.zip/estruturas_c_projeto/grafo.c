#include "grafo.h"
#include <stdio.h>
#include <stdlib.h>
int grafo_init(Grafo*g,size_t n){g->vertices=n;g->listas=calloc(n,sizeof(Aresta*));return g->listas!=NULL;}
static int add_one(Grafo*g,size_t a,size_t b){Aresta*n=malloc(sizeof(*n));if(!n)return 0;n->destino=b;n->prox=g->listas[a];g->listas[a]=n;return 1;}
int grafo_add_edge(Grafo*g,size_t a,size_t b){if(a>=g->vertices||b>=g->vertices)return 0;if(!add_one(g,a,b))return 0;if(a!=b&&!add_one(g,b,a)){return 0;}return 1;}
void grafo_print_neighbors(const Grafo*g,size_t v){if(v>=g->vertices){puts("vertice invalido");return;}for(Aresta*p=g->listas[v];p;p=p->prox)printf("%zu ",p->destino);puts("");}
void grafo_free(Grafo*g){if(!g->listas)return;for(size_t i=0;i<g->vertices;i++){Aresta*p=g->listas[i];while(p){Aresta*n=p->prox;free(p);p=n;}}free(g->listas);g->listas=NULL;g->vertices=0;}
