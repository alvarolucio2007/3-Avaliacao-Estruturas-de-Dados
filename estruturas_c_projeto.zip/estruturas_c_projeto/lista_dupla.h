#ifndef LISTA_DUPLA_H
#define LISTA_DUPLA_H
typedef struct ListaDuplaNo {int valor;struct ListaDuplaNo *ant,*prox;} ListaDuplaNo;
typedef struct {ListaDuplaNo *inicio,*fim;} ListaDupla;
void lista_dupla_init(ListaDupla*l);
int lista_dupla_push_back(ListaDupla*l,int x);
int lista_dupla_remove(ListaDupla*l,int x);
void lista_dupla_print(const ListaDupla*l);
void lista_dupla_free(ListaDupla*l);
#endif
