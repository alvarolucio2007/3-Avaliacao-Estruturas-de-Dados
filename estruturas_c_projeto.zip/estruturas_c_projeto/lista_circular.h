#ifndef LISTA_CIRCULAR_H
#define LISTA_CIRCULAR_H
typedef struct LCNo {int valor;struct LCNo*prox;} LCNo;
typedef struct {LCNo*ultimo;} ListaCircular;
void lista_circular_init(ListaCircular*l);
int lista_circular_push_back(ListaCircular*l,int x);
void lista_circular_print(const ListaCircular*l);
void lista_circular_free(ListaCircular*l);
#endif
