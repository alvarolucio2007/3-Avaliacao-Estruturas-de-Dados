#ifndef LISTA_H
#define LISTA_H
typedef struct ListaNo { int valor; struct ListaNo *prox; } ListaNo;
typedef struct { ListaNo *inicio; } Lista;
void lista_init(Lista *l);
int lista_push_front(Lista *l,int valor);
int lista_push_back(Lista *l,int valor);
int lista_remove(Lista *l,int valor);
int lista_contains(const Lista *l,int valor);
void lista_print(const Lista *l);
void lista_free(Lista *l);
#endif
