#include "vetor.h"
#include <stdio.h>
#include <stdlib.h>
void vetor_init(Vetor *v){v->dados=NULL;v->tamanho=0;v->capacidade=0;}
int vetor_push(Vetor *v,int x){
 if(v->tamanho==v->capacidade){size_t nc=v->capacidade? v->capacidade*2:4; int *p=realloc(v->dados,nc*sizeof(int)); if(!p)return 0;v->dados=p;v->capacidade=nc;}
 v->dados[v->tamanho++]=x;return 1;
}
int vetor_get(const Vetor*v,size_t i,int*out){if(i>=v->tamanho||!out)return 0;*out=v->dados[i];return 1;}
int vetor_set(Vetor*v,size_t i,int x){if(i>=v->tamanho)return 0;v->dados[i]=x;return 1;}
void vetor_print(const Vetor*v){for(size_t i=0;i<v->tamanho;i++)printf("%d ",v->dados[i]);puts("");}
void vetor_free(Vetor*v){free(v->dados);vetor_init(v);}
