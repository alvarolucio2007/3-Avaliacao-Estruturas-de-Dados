#ifndef PILHA_H
#define PILHA_H
typedef struct PilhaNo {int valor;struct PilhaNo*prox;} PilhaNo;
typedef struct {PilhaNo*topo;} Pilha;
void pilha_init(Pilha*p);
int pilha_push(Pilha*p,int x);
int pilha_pop(Pilha*p,int*out);
int pilha_peek(const Pilha*p,int*out);
int pilha_empty(const Pilha*p);
void pilha_free(Pilha*p);
#endif
